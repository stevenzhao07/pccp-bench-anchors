10 题盲标小包。先读 blind_kit/README_盲标.md。包内不含答案。
算 κ 用 tools/kappa.py --selftest 自检，再 --a/--b 算。
