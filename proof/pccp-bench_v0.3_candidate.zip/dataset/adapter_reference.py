"""Reference adapter（v0.3）：先展开编码，再用同一个判器。

v0.3 事实把两个被压扁的标志拆成四个：
  claimed_pccp_coverage / actually_within_scope   （主张 vs 事实）
  criteria_measured / criteria_met                （测没测 vs 达没达）
本文件在编码层把它们展开回判器认识的九标志，判器一行未改。

展开式（四种组合逐一验过，见 v03编码层修复_20261127.md）：
  change_within_pccp_scope = claimed AND (actual OR NOT authorized)
  acceptance_criteria_met  = None 若未按类型测；否则 = met

标签优先级 = R1 语义（可补救 → hold，不可补救 → reject），11 字词表。
"""
from __future__ import annotations

import os
import sys

ENGINE_ROOT = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, ENGINE_ROOT)
from lgd_engine.judges.judge_pccp import JudgePccpScope  # noqa: E402

_JUDGE = JudgePccpScope()

RULE_TO_TAG = [
    ("P-CRIT-04", "not_se_to_predicate"),
    ("P-CRIT-05", "not_se_to_predicate"),
    ("P-CRIT-02", "intended_use_change"),
    ("P-CRIT-01", "no_pccp_authorized"),
    ("P-CRIT-03", "acceptance_not_met"),
    ("P-MAJ-01", "outside_scope"),
    ("P-MAJ-03", "validation_missing"),
    ("P-MAJ-05", "labeling_version_history_missing"),
    ("P-MAJ-06", "udi_not_regenerated"),
    ("P-MAJ-04", "unclassifiable"),
    ("P-MAJ-07", "evidence_missing"),
    ("L2-EVIDENCED", "evidence_missing"),
]


def expand(ctx):
    ctx = dict(ctx)
    auth = ctx.get("pccp_authorized")
    claim = ctx.get("claimed_pccp_coverage")
    actual = ctx.get("actually_within_scope")
    if claim is None:
        claim = ctx.get("change_within_pccp_scope")
    if actual is None:
        actual = ctx.get("change_within_pccp_scope")
    ctx["change_within_pccp_scope"] = bool(claim) and (bool(actual) or auth is False)

    measured = ctx.get("criteria_measured")
    if measured is None:
        pass
    elif measured is not True:
        ctx["acceptance_criteria_met"] = None
    else:
        ctx["acceptance_criteria_met"] = ctx.get("criteria_met")
    return ctx


def _tag(verdict, reasons):
    fired = [str(r.get("rule", "")) if hasattr(r, "get") else str(r) for r in reasons]
    for prefix, tag in RULE_TO_TAG:
        if any(f.startswith(prefix) for f in fired):
            return tag
    if verdict == "go":
        return "ok_covered"
    return "unclassifiable"


def evaluate(ctx):
    res = _JUDGE.evaluate(expand(ctx))
    verdict = res.get("verdict")
    return {"verdict": verdict, "tag": _tag(verdict, res.get("reasons", [])),
            "reasons": res.get("reasons", [])}
