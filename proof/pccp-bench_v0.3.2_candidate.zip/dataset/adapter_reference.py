"""Reference adapter（v0.3.2）：先展开编码，再用同一个判器。

v0.3.1 起判器从包内 snapshot 取。v0.3.2 只加一条：**冲突就判不了，不静默丢弃**。

背景（见真实回放最小编码表_20261127.md 与 corpus_replay_probe.py 的静默覆盖探针）：
  v0.3 把 acceptance 拆成 criteria_measured / criteria_met，同时保留 v0.2 的
  acceptance_criteria_met。适配器在 criteria_measured=True 时用 criteria_met 覆盖
  acceptance_criteria_met —— 也就是说，只有一边被填、另一边是旧字段名时，
  旧字段名的取值被**无声丢掉**。实测：只填 acceptance_criteria_met=False → go；
  填 criteria_met=False → reject。同名两义、填错名字不报错，最容易被外人踩。

本版做法：
  1 两边都在且不一致 → 该格置 None（判器视为必填缺失 → hold，绝不放过）；
  2 只一边在 → v0.3 名优先，v0.2 名兜底；
  3 冲突字段名写进 `_encoding_conflicts`，随判决返回，不藏。
判器字节一字未动。
"""
from __future__ import annotations

import os
import sys

PKG_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if PKG_ROOT not in sys.path:
    sys.path.insert(0, PKG_ROOT)
from snapshot.judge_pccp import JudgePccpScope  # noqa: E402

_JUDGE = JudgePccpScope()

RULE_TO_TAG = [
    ("P-CRIT-04", "not_se_to_predicate"),
    ("P-CRIT-05", "not_se_to_predicate"),
    ("P-CRIT-02", "intended_use_change"),
    ("P-CRIT-01", "no_pccp_authorized"),
    ("P-CRIT-03", "acceptance_not_met"),
    ("P-MAJ-01", "outside_scope"),
    ("P-MAJ-03", "validation_missing"),
    ("P-MAJ-05", "labeling_version_history_missing"),
    ("P-MAJ-06", "udi_not_regenerated"),
    ("P-MAJ-04", "unclassifiable"),
    ("P-MAJ-07", "evidence_missing"),
    ("L2-EVIDENCED", "evidence_missing"),
]


def expand(ctx):
    ctx = dict(ctx)
    conflicts = []

    auth = ctx.get("pccp_authorized")
    claim = ctx.get("claimed_pccp_coverage")
    actual = ctx.get("actually_within_scope")
    legacy_scope = ctx.get("change_within_pccp_scope")
    if claim is None:
        claim = legacy_scope
    if actual is None:
        actual = legacy_scope
    computed = bool(claim) and (bool(actual) or auth is False)
    if (legacy_scope is not None and claim is not None and actual is not None
            and computed != bool(legacy_scope)):
        conflicts.append("change_within_pccp_scope")
        ctx["change_within_pccp_scope"] = None
    else:
        ctx["change_within_pccp_scope"] = computed

    measured = ctx.get("criteria_measured")
    if measured is None:
        pass
    elif measured is not True:
        ctx["acceptance_criteria_met"] = None
    else:
        met = ctx.get("criteria_met")
        legacy_met = ctx.get("acceptance_criteria_met")
        if met is not None and legacy_met is not None and bool(met) != bool(legacy_met):
            conflicts.append("acceptance_criteria_met")
            ctx["acceptance_criteria_met"] = None
        else:
            ctx["acceptance_criteria_met"] = met if met is not None else legacy_met

    if conflicts:
        ctx["_encoding_conflicts"] = conflicts
    return ctx


def _tag(verdict, reasons):
    fired = [str(r.get("rule", "")) if hasattr(r, "get") else str(r) for r in reasons]
    for prefix, tag in RULE_TO_TAG:
        if any(f.startswith(prefix) for f in fired):
            return tag
    if verdict == "go":
        return "ok_covered"
    return "unclassifiable"


def evaluate(ctx):
    expanded = expand(ctx)
    conflicts = expanded.pop("_encoding_conflicts", None)
    res = _JUDGE.evaluate(expanded)
    out = {"verdict": res.get("verdict"), "tag": _tag(res.get("verdict"), res.get("reasons", [])),
           "reasons": res.get("reasons", [])}
    if conflicts:
        out["encoding_conflicts"] = conflicts
        out["conflict_policy"] = "conflicting legacy/new field names -> treated as missing -> hold"
    return out
