#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""selfcheck.py —— 不给网络、不给环境变量，跑完就知道这包能不能用。

它只回答三件事：
  1  包里的判器 + 包里的适配器能不能 import（不能就报 IMPORT_FAIL，退出码 2）
  2  51 条上判决与标签是否一致（不一致就把 case_id 列出来）
  3  题集本身的 sha256（别人拿到同一份包，sha 必须一样）

用法（在包根目录）：
  python dataset/selfcheck.py
"""
import hashlib
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
PKG_ROOT = os.path.dirname(HERE)
sys.path.insert(0, PKG_ROOT)
sys.path.insert(0, HERE)

CASES = os.path.join(HERE, "cases_public.json")


def main() -> int:
    raw = open(CASES, "rb").read()
    print("cases_sha256   " + hashlib.sha256(raw).hexdigest())
    doc = json.loads(raw.decode("utf-8"))
    cases = doc.get("cases", doc)

    try:
        import adapter_reference as adapter
    except Exception as exc:
        print("IMPORT_FAIL    " + type(exc).__name__ + ": " + str(exc))
        return 2

    verdict_ok = tag_ok = 0
    misses = []
    tag_misses = []
    for c in cases:
        ctx = {k: v for k, v in c.items() if not k.startswith("expected_")}
        res = adapter.evaluate(ctx)
        if res.get("verdict") == c.get("expected_verdict"):
            verdict_ok += 1
        else:
            misses.append((c["case_id"], res.get("verdict"), c.get("expected_verdict")))
        if res.get("tag") == c.get("expected_tag"):
            tag_ok += 1
        else:
            tag_misses.append((c["case_id"], res.get("tag"), c.get("expected_tag")))

    n = len(cases)
    print("verdict_match  %d/%d" % (verdict_ok, n))
    print("tag_rate       %.4f" % (tag_ok / n))
    for m in misses:
        print("  MISS  %s  got=%s  want=%s" % m)
    for m in tag_misses[:10]:
        print("  TAG   %s  got=%s  want=%s" % m)
    overall = "SELFCHECK_ALL_PASS" if verdict_ok == n and tag_ok == n else "SELFCHECK_HAS_FAIL"
    print(overall)
    return 0 if overall == "SELFCHECK_ALL_PASS" else 1


if __name__ == "__main__":
    sys.exit(main())
