@echo off
setlocal
cd /d "%~dp0"
echo ============================================================
echo   PCCP-Bench public self-check
echo   This is NOT a score. There is no held-out set in this bundle.
echo ============================================================
echo.
where python >nul 2>nul
if errorlevel 1 goto nopython
python --version
if errorlevel 1 goto nopython
echo.
echo [1/2] bundle integrity: hidden commitment vs shipped bytes
python bench.py --commit-check
echo.
echo [2/2] run the demo adapter through the scorer
echo       The demo answers "hold" to everything, so a low number here is
echo       expected. Replace bench_template.py with your own judge to see yours.
python bench.py --submit bench_template.py --team selfcheck-demo
echo.
echo ------------------------------------------------------------
echo Done. Copy this window's text back as-is, success or error.
echo ------------------------------------------------------------
pause
exit /b 0

:nopython
echo.
echo [STOP] Python was not found on this machine.
echo        Install Python 3.9 or newer from python.org and tick
echo        "Add python.exe to PATH", then run this file again.
echo.
pause
exit /b 2
