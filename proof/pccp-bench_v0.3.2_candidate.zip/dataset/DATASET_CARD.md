# 数据集卡片（Datasheet）：PCCP-Bench v1.1

写这张卡的理由很直接：台子要能被别人**引用**，就得说清楚它是怎么造出来的、哪儿靠不住。只给两份 JSON 和一个榜单，别人无法判断该不该信。

## 1. 它是什么

给定一条**变更事实**（是否在授权 PCCP 内、是否触及预期用途、验收判据是否达标、证据是否在位…），要求判定 `go / reject / hold`，并说出理由（六个词之一）。

不是：不是准确率榜，不是监管结论，不是"医疗器械变更是否需要新 510(k)"的法律意见。

## 2. 规模与切分

| 项 | 值 |
|---|---|
| 总题数 | **42** |
| 公开 / 隐藏 | **32 / 10** |
| 类型 | `described` 33、`boundary` 9 |
| 结论分布 | go 37、hold 5、**reject 0**（见 §5.2：本台不承认"拒绝"这一档，凡"计划外"都是 hold） |
| 理由分布 | ok_covered 37、outside_scope 2、acceptance_not_met 1、unclassifiable 1、intended_use_change 1 |
| 数据集摘要 | `dataset_sha256` 前 12 位 **`47470fef0dbf`**（见 `dataset_manifest.json`） |

切分规则：`sha256("split-" + case_id)` 的**前 8 位**映射到 [0,1)，小于 0.3 进隐藏。写死、只按 id 算，因此**改一条题的 facts 不会让另一条题跨过半区**。这条是刻意的：否则调参的人可以靠改题把难题挪走。

## 3. 来源

- **33 题** 取自 16 份 FDA 公开的 510(k)/De Novo 授权摘要中 PCCP 章节的 Table 条目（如 K260906、K261623、K254297、K253281 等）。每例在 `source` 里带文档号、Table 锚点与摘要 URL。
- **8 题** 回放边界样例，源于 K260973（InferOperate）、DEN250057（PCWP Analysis）、P240006（TRUPULSE）三份授权文件的 PCCP 与衍生边界。
- **1 题** 取自 K260217 摘要原文的一句否定判断（"属新 510(k)，不是 PCCP 内修改"）。

## 4. 标注是谁做的、有多硬

这是最关键的一栏，`label_provenance` 逐题标注：

| 值 | 题数 | 含义 | 硬度 |
|---|---|---|---|
| `fda_authorized_table` | 33 | 该修改已被 FDA 批在计划内，故 `go` 由文件本身给出 | 中：结论硬，但题面 facts 是我按"合规记录"填的 |
| `author_argued` | 6 | 我读了规则原文后判的 | 低：单人、无第二人复核 |
| `author_argued_corrected` | 3 | **我第一版判错、后按规则原文改正**的 | 低但是透明的 |

那 3 条改正过的题（`K260973-N1`、`K260973-H1`、`K260217`）都曾被我写成 `reject`，实际应为 `hold`——因为 §515C 不覆盖 ≠ 变更被禁止，只是必须另交申请。这个错我犯过两次（K260973-N1 一次、K260217 一次），所以把它写进元数据而不是藏起来。

**没有任何一条标注来自第三方。** 42 题全部由出题人自己标注，这也是为什么参考实现能拿满分：题、答案、评分器同一双手。

| `author_reconstructed` | 33 | 题面字段是我按"合规记录应有的样子"补的 |
| `replay_from_document` | 8 | 从授权文件正文回放的边界情形 |
| `document_quote` | 1 | 直接引原文一句否定判断（K260217） |

## 5. 已知偏差（用之前必须知道）

1. **类别不均衡**：37:5。`exact_rate` 会被"全押 go"骗到 **0.875**，而它的 `macro_recall` 只有 **0.3333**。所以每次跑分器都把这条基线**打在成绩下面两行**（`baseline: always-'go' ...`），不是只写在这张纸上。
2. **难度偏低**：33 题只需认出"这是一份合规记录"，真正考验判定的是 9 题。
3. **题面是我拼的**：逐题标 `facts_provenance` —— `author_reconstructed` 33（`jurisdiction=FDA`、`acceptance_criteria_met` 等字段是我按合规记录应有的样子补的）、`replay_from_document` 8、`document_quote` 1。补得对不对，没有第二人核过。
4. **来源集中**：16 份文件、3 个器械族，不能代表 170 台已获 PCCP 的器械整体（RSNA 2026 统计）。
5. **无外部提交**：隐藏列从未被外人跑过。

### 5.1 `masked` 列是什么、不是什么

一位外部审查员把它说成"人为削弱难度、显示虚假严谨的花招"。这个说法我只接一半：

- **它不测难度**。抹掉题面里"这是一份已批准案例"的提示字段，不会让题变难，它只是**掐掉一条捷径**——照答案表答题的人正走在这条捷径上。所以 `masked` 是**泄漏探针**，不是难度分。谁把 masked 的分数读成"更难一档"，本卡不支持。
- **不撤掉它**。它是唯一能把"背答案"跟"真判定"分开的列：背题者 public 1.0 → masked **0.0938**，参考实现 1.0 → 1.0。撤掉这列，台子就只剩一个谁都能拿高分的列。
- 代价我认：masked 列上的低分**不能**解释成"真实使用里上下文不足"，它只说明"没有上下文时不许背"。

### 5.2 `reject` 与 `hold`：**已定为 hold，与引擎不一致的 2 例明写**

第三方盲判（下节）把我的定义缺口照了出来。同一条变更，三处三种结论，而**理由完全相同**：

| 情形 | 引擎 | 本台现在的标签 | 第三方盲判 |
|---|---|---|---|
| 判据未达标（H1） | reject | **hold** | hold |
| 预期用途变更（N2） | reject | **hold** | hold |
| 范围外（N1、K260217） | hold | hold（原写 reject，已改） | hold |

**本台的口径（写死）**：

- **`reject`**：只用于"本计划明确禁止、且不得以此形式在此计划下推进"；
- **`hold`**：判据未达标、计划外范围、预期用途变更，一律 hold（回到计划外另交）。

依据 §515C(b)：不覆盖 ≠ 禁止。**所以本台现在 0 条 `reject`。**

**代价如实记**：引擎（`judge_pccp.py`，`7ee356eacef9`）在这两条上仍给 `reject`，所以参考实现——它就是引擎——**不再是满分**：

| 列 | 参考实现 | 说明 |
|---|---|---|
| public | **0.9688** | 只错 `K260973-H1-DICE-MISS` |
| masked | **0.9688** | 同上 |
| hidden | **0.9** | 只错 `K260973-N2-PEDIATRIC` |
| 理由轴 | 1.0 | 不受影响 |

这不是回归，**这是证据**：它证明"本台的判定口径与引擎输出有 2/42 的分歧"，而不是靠一句声明。改引擎需单独批准，未动。

## 6. 第三方盲判交叉核对（v1.1 新增）

把 9 条**作者自判**标签（33 条 FDA 授权表标签不在此列）发给第三方模型 `DeepSeek-V3` 盲判：只给变更事实与器械描述，**不给期望答案、不给我的规则编号**。

| 轴 | 一致 |
|---|---|
| 结论（go/reject/hold） | **6/9** |
| 理由（六词） | **8/9** |

一致的那 6 条，正好是 4 条"计划内"和 2 条"范围外"。分歧 3 条：2 条是 reject/hold 语义（见 5.2），1 条是真问题——

**`P240006-HW-COVERAGE-GAP`**：我标 `hold/unclassifiable`，理由是 `change_type=hardware_change` 不在引擎的 9 类闭集里。对方眼里这就是一条普通的计划内硬件变更，判 `go/ok_covered`——**结论和理由都不一致**。这条标签反映的是我的分类法，不是监管事实，已标为词汇伪影，不因它给台子加分。

**先说我自己在这件事上犯的错**：我第一版把理由轴写成 9/9。探针对着逐行记录自己算，算出 **8/9**——漏了 P240006 的理由也不一致。数字是我手填的，探针是算出来的，**这次是探针赢**。

**理由轴仍比结论轴结实（8/9 对 6/9）**：差的那一条不是"定义缺失"，是我把自家分类法的边界混进了监管判断。反过来说，一个只比结论的台子会把 5.2 那种定义缺口当成错误，而它其实不是。

### 6.1 在别人家的版本上跑过（实测，非推断）

| 环境 | Python | 入口 | 结果 |
|---|---|---|---|
| Windows 11 / pwsh | 3.13.18 | 双击 `跑自测.bat` | COMMIT PASS，demo 0.125，正常退出 |
| `python:3.8-slim` 容器 / debian + dash | **3.8.20** | `bench.py --commit-check` | PASS（无隐藏题时如实打印"验不了"） |
| 同上 | **3.8.20** | `sh 跑自测.sh` | 两步全跑通 |

**没测过的**：Python 3.7 及更早、Windows 默认 **GBK 控制台**下中文文件名的显示、Microsoft Store 的 `python` 占位程序、**未装 Python** 的机器上 `.bat` 的提示是否真能让人装明白、**macOS 真机**。

这张表的意义只有一个：把"外人第一次摔跤"从推断变成两次实测。**它仍然不是外部实跑**——环境是我起的容器，不是别人的机器。

## 7. 许可与来源权利
- FDA 摘要属美国政府作品，可公开引用；本卡逐题给出 `source_url` 以便逐条核。
- 本项目的**整理、评分器与适配器**：暂不授权对外分发、二次发布或商用；公开与开仓均需 Steven Zhao 书面同意。**本数据集至今零外发**。

## 8. 怎么复核这张卡

```
python build_cases.py          # 重算 42 题、重算 dataset_sha256、重写 case_index.csv
python bench.py --commit-check # 隐藏集承诺 vs 实际字节
python probe_bench.py          # 30 条断言，含"卡上数字与文件一致"
```

三条命令都不需要网络。任何人重算出的 `dataset_sha256` 与 `dataset_manifest.json` 不一致，就说明我改过题。

## 9. 引用方式（若日后发布）

> PCCP-Bench v1.1（2026-11-26），42 例，dataset_sha256 `47470fef0dbf…`。作者自评数据集；9 条作者自判标签经第三方模型盲判交叉核对（结论 6/9、理由 8/9）；reject/hold 已定为 hold（与引擎 2/42 分櫚）。


## v0.3（2026-11-27，候选，未发布）

- 事实层：新增 `claimed_pccp_coverage` / `actually_within_scope` / `criteria_measured` / `criteria_met` 四个字段，
  把 v0.2 里"一颗标志兼两义"的缺陷拆开。老九标志全部保留（向后兼容）。
- 词表：`TAGS` 由 6 字扩到 11 字。原因有实例——`SYN-NO-PCCP-ROADMAP` 判出 reject，
  而六字词表没有"没有授权 PCCP"这个词，只能落 `unclassifiable`。
- 判器：`snapshot/judge_pccp.py` **一字未改**。编码展开在 adapter 里做，
  兼容性回归 51 条 0 判决变化。
- 标签语义：R1（可补救 → hold，不可补救 → reject），逐条由写死的规则表推导，来源字段标 `label_provenance`。
- 仍存在的缺口：题面长度中位仍低于 FDA `ao_statement` 中位 463 字符；`reject` 与 `affects_intended_use=True`
  覆盖偏少；10 条隐藏题不随包发布；无真实 PCCP 变更回放。


## v0.3.1（2026-11-27，候选，未发布）—— 修"包不能自跑"

把 v0.3 包解到**空目录**、用隔离解释器导入，两条致命错当场暴露：

1. `dataset/adapter_reference.py` 写的是 `from lgd_engine.judges.judge_pccp import ...`，
   包里没有 `lgd_engine`；
2. `snapshot/judge_pccp.py` 是 `from .base import ...`，包里既没有 `snapshot/base.py`，
   也没有 `snapshot/__init__.py`。

结论：**v0.3 包对外人不可运行**。此前所有"51/51、标签率 1.0"的读数，都是在作者自己的引擎树里
跑出来的（那儿有 `lgd_engine`）。这不是数据错，是包装错，但后果一样——外人一跑就
ModuleNotFoundError。

本版修（判器字节一字未动）：
- 打进 `snapshot/__init__.py` 与 `snapshot/base.py`（base 取**重建版**，文件内带
  RECONSTRUCTED 标注：其中 `is_unusable` / `misused` 是按判器唯一调用点重建的，
  **不是**作者原字节）；
- adapter 改为 `from snapshot.judge_pccp import JudgePccpScope`，路径以包根为准；
- 新增 `dataset/selfcheck.py`：无依赖、无网络，一条命令输出判决一致数 / 标签率 / 题集 sha；
- `MANIFEST.json`、`dataset/dataset_manifest.json` 按实际内容重算（原 MANIFEST 还挂着
  v0.1 的 `leaf_count=14` 与 v0.1 判器 sha —— 清单与内容不同源，属同类缺陷）。

仍然不是：不是发布版；隐藏题不随包发；没有真实变更回放；`base.py` 不是作者原字节。


## v0.3.2（2026-11-27，候选，未发布）—— 冲突不再静默

量化事实：v0.3 适配器在 `criteria_measured=True` 时用 `criteria_met` 覆盖
`acceptance_criteria_met`。于是只填旧字段名 `acceptance_criteria_met=False` → 判决 **go**；
填新字段名 `criteria_met=False` → **reject / acceptance_not_met**。同一个概念两个名字，
填错名字不报错、只改结论。

v0.3.2 只改编码层（判器一字未动）：两边都在且不一致 → 该格置 None（判器按"必填缺失"给 hold），
冲突字段名随判决返回（`encoding_conflicts`）。没有冲突的老用法完全不变。
