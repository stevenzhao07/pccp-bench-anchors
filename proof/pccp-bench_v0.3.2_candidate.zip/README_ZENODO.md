# PCCP-Bench v0.1.0 — deposit 说明（Zenodo 上传用）

这是"站位"用的字节包，不是产品页。上传前请先看完三件事。

## 1. 包里有什么

```
dataset/                 13 个文件：公开 32 题、题索引、数据集卡、隐藏题承诺、评分器、参考适配器、README、跑自测脚本、公开自测包
judge_pccp.py            引擎快照（sha256 前 12 = 7ee356eacef9），只读，不带可写依赖
MANIFEST.json            14 个叶子的逐文件 sha256 + Merkle 规则
ROOT.txt                 冻结时刻的根（2026-11-26）
CITATION.cff             引用格式（许可证字段待填）
LICENSE_STATUS.md        许可证状态：**尚未选定**
```

**根覆盖的是 14 个叶子**（dataset 13 + 引擎快照 1）。`MANIFEST.json`、`ROOT.txt`、本说明、`CITATION.cff` 不算叶子——它们是账本，与 `.git` 同类，不能自己盖自己。

## 2. 能声称什么 / 不能声称什么

能：公开可下载、一条命令可跑、每题有 verdict 与理由标签、有逐文件哈希与固定根、四环境（Windows / Linux glibc / 非 root / alpine musl）复跑同摘要。

不能：不能说"被 FDA 认可/验证"；不能写"首个/唯一"（只能说"截至 2026-11-26 本轮检索未查到同类公开题集"）；不能写"已被外部团队实跑"（外部回传 0 份）；不能写"标注可靠性高"（无第二标注人、无 κ）。

## 3. 上传前的硬门槛

- **许可证未定 → 不能点发布。** 建议数据 CC BY 4.0、代码 Apache-2.0，但这是对外法律承诺，需本人确认。
- 隐藏题 10 题**不在**这个包里；只放了它们的承诺哈希（`dataset/hidden_commitment.json`）。
- 上传后务必把 concept DOI 与 version DOI 回填到 `standing_entry.json` 与登记册，再跑 `standing_probe.py`。

## 4. 上传后怎么被别人验（三条命令，均已在本机洁净目录实跑过）

```
python bench.py --submit adapter_reference.py --team reference   # 自检两列：public 0.9688 / masked 0.9688 / tag 1.0
python bench.py --commit-check                                   # 10 条隐藏题承诺（字节不在此包，只验条数）
python bench.py --verify <score_json>                            # 复算某份成绩：行→分数、摘要是否一致
```

注意 `--verify` 要一个**成绩 JSON**，不是这个 zip；给 zip 会报 UnicodeDecodeError（第一版说明书写错过，已改）。

跑分器每次都会打印一行基线：`baseline: always-'go' scores exact=0.875 but macro_recall=0.5 -- exact alone is not a result.`
没有 held-out 集合时会额外提示"这是两列自检，不是成绩"——这是故意的，不让人把自检当排名。

## 5. 复算根

任何人可对 `dataset/` 与 `judge_pccp.py` 重算：叶子 = sha256(`path\x00file_sha256`)，成对 sha256(a+b)，奇数节点与自身配对。结果应等于 `ROOT.txt` 里的 `2d305387f618…`。
