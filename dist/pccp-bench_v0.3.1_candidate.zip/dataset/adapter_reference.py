"""Reference adapter（v0.3.1）：先展开编码，再用同一个判器。

与 v0.3 的差别只有一行：判器从包内 snapshot 取，不再假设本机存在 lgd_engine。
（v0.3 的写法在外人机器上必然 ModuleNotFoundError，见 DATASET_CARD 的 v0.3.1 段。）

展开式（四种组合逐一验过，见 v03编码层修复_20261127.md）：
  change_within_pccp_scope = claimed AND (actual OR NOT authorized)
  acceptance_criteria_met  = None 若未按类型测；否则 = met

标签优先级 = R1 语义（可补救 → hold，不可补救 → reject），11 字词表。
"""
from __future__ import annotations

import os
import sys

PKG_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if PKG_ROOT not in sys.path:
    sys.path.insert(0, PKG_ROOT)
from snapshot.judge_pccp import JudgePccpScope  # noqa: E402

_JUDGE = JudgePccpScope()

RULE_TO_TAG = [
    ("P-CRIT-04", "not_se_to_predicate"),
    ("P-CRIT-05", "not_se_to_predicate"),
    ("P-CRIT-02", "intended_use_change"),
    ("P-CRIT-01", "no_pccp_authorized"),
    ("P-CRIT-03", "acceptance_not_met"),
    ("P-MAJ-01", "outside_scope"),
    ("P-MAJ-03", "validation_missing"),
    ("P-MAJ-05", "labeling_version_history_missing"),
    ("P-MAJ-06", "udi_not_regenerated"),
    ("P-MAJ-04", "unclassifiable"),
    ("P-MAJ-07", "evidence_missing"),
    ("L2-EVIDENCED", "evidence_missing"),
]


def expand(ctx):
    ctx = dict(ctx)
    auth = ctx.get("pccp_authorized")
    claim = ctx.get("claimed_pccp_coverage")
    actual = ctx.get("actually_within_scope")
    if claim is None:
        claim = ctx.get("change_within_pccp_scope")
    if actual is None:
        actual = ctx.get("change_within_pccp_scope")
    ctx["change_within_pccp_scope"] = bool(claim) and (bool(actual) or auth is False)

    measured = ctx.get("criteria_measured")
    if measured is None:
        pass
    elif measured is not True:
        ctx["acceptance_criteria_met"] = None
    else:
        ctx["acceptance_criteria_met"] = ctx.get("criteria_met")
    return ctx


def _tag(verdict, reasons):
    fired = [str(r.get("rule", "")) if hasattr(r, "get") else str(r) for r in reasons]
    for prefix, tag in RULE_TO_TAG:
        if any(f.startswith(prefix) for f in fired):
            return tag
    if verdict == "go":
        return "ok_covered"
    return "unclassifiable"


def evaluate(ctx):
    res = _JUDGE.evaluate(expand(ctx))
    verdict = res.get("verdict")
    return {"verdict": verdict, "tag": _tag(verdict, res.get("reasons", [])),
            "reasons": res.get("reasons", [])}
